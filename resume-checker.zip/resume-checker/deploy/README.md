# Linux VM Deployment

Deploy Resume Checker on a Linux VM behind Nginx + Gunicorn + systemd.

## What this folder contains

| File | Purpose |
|---|---|
| `nginx-resume-checker.conf` | Nginx reverse-proxy site (port 80 → 127.0.0.1:5000) |
| `resume-checker.service` | systemd unit that runs the app under Gunicorn |
| `deploy.sh` | One-shot bootstrap script for Ubuntu/Debian VMs |
| `README.md` | This guide |

## Architecture

```
Browser ──HTTP──▶  Nginx (:80 /:443)  ──proxy──▶  Gunicorn (:5000)
                        │                              │
                        ▼                              ▼
                 /opt/resume-checker/static/     Flask app (app:app)
                                                       │
                                      ┌────────────────┼──────────────────┐
                                      ▼                ▼                  ▼
                              rule_based tailor   Ollama (:11434)   OpenAI-compatible API
```

- **Nginx** terminates HTTP(S), serves `/static/` directly, proxies everything else.
- **Gunicorn** (3 workers × 2 threads) runs the Flask app as `resumecheck` user.
- **systemd** auto-restarts on crash and starts on boot.
- **AI provider** is picked by env vars inside the unit file.

---

## One-shot install (Ubuntu 22.04 / 24.04)

Copy the whole `resume-checker/` folder to the VM (e.g. with `scp`), then:

```bash
cd /path/to/resume-checker
sudo bash deploy/deploy.sh
```

That script will:

1. `apt install python3-venv nginx rsync`
2. Create a `resumecheck` system user
3. Sync the project to `/opt/resume-checker`
4. Build the venv and install `requirements.txt`
5. Install + start the systemd unit
6. Install + enable the nginx site, test the config, reload

Then open **http://<your-vm-ip>/** — you should see the Resume Checker UI.

### Verify

```bash
systemctl status resume-checker
journalctl -u resume-checker -f
curl -s http://127.0.0.1:5000/api/health   # → {"status":"ok"}
curl -s http://127.0.0.1/api/health        # same, via nginx
```

---

## Enable AI tailoring

### Option A — Local Ollama (recommended for self-contained VM)

```bash
# Install Ollama
curl -fsSL https://ollama.com/install.sh | sh
systemctl enable --now ollama

# Pull a model (choose based on VM RAM):
#   llama3.1:8b     ~ 5 GB,  needs 8 GB free RAM, CPU OK
#   mistral:7b      ~ 4 GB
#   phi3:mini       ~ 2 GB,  for small VMs
ollama pull llama3.1:8b

# Switch the service to Ollama
sudo systemctl edit resume-checker
# Add:
#   [Service]
#   Environment="AI_PROVIDER=ollama"
#   Environment="AI_MODEL=llama3.1:8b"
#   Environment="OLLAMA_URL=http://127.0.0.1:11434"
sudo systemctl restart resume-checker
```

Verify the active provider:

```bash
curl -s http://127.0.0.1:5000/api/ai-info
# → {"provider":"ollama","model":"llama3.1:8b", ...}
```

### Option B — OpenAI-compatible API

Supports **OpenAI**, **Azure OpenAI**, **Groq**, **Together**, **LM Studio**,
**Mistral API**, etc.

```bash
# Put your key in a protected file:
sudo install -m 600 /dev/stdin /etc/default/resume-checker <<'EOF'
OPENAI_API_KEY=sk-...
EOF

# Edit the unit:
sudo systemctl edit resume-checker
# Add:
#   [Service]
#   Environment="AI_PROVIDER=openai"
#   Environment="AI_MODEL=gpt-4o-mini"
#   Environment="OPENAI_API_BASE=https://api.openai.com/v1"
#   EnvironmentFile=-/etc/default/resume-checker

sudo systemctl restart resume-checker
```

For Groq, for example, set `OPENAI_API_BASE=https://api.groq.com/openai/v1`
and `AI_MODEL=llama-3.1-70b-versatile`.

---

## HTTPS with Let's Encrypt

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d resume.yourdomain.com
# Certbot will rewrite the nginx config to redirect 80 → 443.
```

The commented HTTPS server block at the bottom of
`nginx-resume-checker.conf` is a reference template if you prefer to
manage certs manually.

---

## Firewall

```bash
sudo ufw allow 'Nginx Full'   # opens 80 + 443
sudo ufw enable
# Do NOT open port 5000 or 11434 externally — nginx/ollama are loopback-only.
```

---

## Updating

```bash
# On your laptop
rsync -av --exclude .venv --exclude __pycache__ \
     resume-checker/ user@vm:/tmp/resume-checker-new/

# On the VM
sudo rsync -a --delete --exclude .venv /tmp/resume-checker-new/ /opt/resume-checker/
sudo chown -R resumecheck:resumecheck /opt/resume-checker
sudo /opt/resume-checker/.venv/bin/pip install -r /opt/resume-checker/requirements.txt
sudo systemctl restart resume-checker
```

---

## Uninstall

```bash
sudo systemctl disable --now resume-checker
sudo rm /etc/systemd/system/resume-checker.service
sudo rm /etc/nginx/sites-enabled/resume-checker.conf /etc/nginx/sites-available/resume-checker.conf
sudo systemctl reload nginx
sudo rm -rf /opt/resume-checker
sudo userdel resumecheck
```
