#!/usr/bin/env bash
# ============================================================================
# Resume Checker — Linux VM bootstrap script
#
# What it does:
#   1. Installs Python 3, venv tools, nginx (Ubuntu/Debian)
#   2. Creates a dedicated 'resumecheck' system user
#   3. Copies the project to /opt/resume-checker
#   4. Creates a venv and installs requirements.txt
#   5. Installs the Gunicorn systemd service
#   6. Installs the nginx reverse-proxy site
#   7. Enables + starts everything
#
# Usage (on the VM):
#   sudo bash deploy/deploy.sh
#
# Tested on: Ubuntu 22.04 / 24.04. Rocky/Alma: swap apt lines for dnf.
# ============================================================================
set -euo pipefail

APP_NAME="resume-checker"
APP_USER="resumecheck"
APP_DIR="/opt/${APP_NAME}"
SERVICE_FILE="/etc/systemd/system/${APP_NAME}.service"
NGINX_SITE_AVAIL="/etc/nginx/sites-available/${APP_NAME}.conf"
NGINX_SITE_ENABL="/etc/nginx/sites-enabled/${APP_NAME}.conf"

SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
echo "==> Source dir : ${SRC_DIR}"
echo "==> Target dir : ${APP_DIR}"

if [[ $EUID -ne 0 ]]; then
  echo "ERROR: must be run as root (use sudo)." >&2
  exit 1
fi

# 1. OS packages ------------------------------------------------------------
echo "==> Installing OS packages (python3-venv, nginx, rsync)…"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y python3 python3-venv python3-pip nginx rsync ca-certificates curl

# 2. App user ---------------------------------------------------------------
if ! id -u "${APP_USER}" >/dev/null 2>&1; then
  echo "==> Creating system user '${APP_USER}'…"
  useradd --system --home "${APP_DIR}" --shell /usr/sbin/nologin "${APP_USER}"
fi

# 3. Copy source ------------------------------------------------------------
echo "==> Syncing project source to ${APP_DIR}…"
mkdir -p "${APP_DIR}"
rsync -a --delete \
      --exclude '.venv' \
      --exclude '__pycache__' \
      --exclude '.pytest_cache' \
      --exclude '.ruff_cache' \
      --exclude '.github' \
      --exclude 'tests' \
      --exclude 'samples/*.pdf' \
      --exclude 'samples/*.docx' \
      --exclude 'deploy/deploy.sh' \
      "${SRC_DIR}/" "${APP_DIR}/"

# 4. Venv + deps ------------------------------------------------------------
echo "==> Creating venv + installing requirements…"
python3 -m venv "${APP_DIR}/.venv"
"${APP_DIR}/.venv/bin/pip" install --upgrade pip
"${APP_DIR}/.venv/bin/pip" install -r "${APP_DIR}/requirements.txt"

chown -R "${APP_USER}:${APP_USER}" "${APP_DIR}"

# 5. systemd unit -----------------------------------------------------------
echo "==> Installing systemd unit → ${SERVICE_FILE}"
install -m 0644 "${SRC_DIR}/deploy/resume-checker.service" "${SERVICE_FILE}"
systemctl daemon-reload
systemctl enable "${APP_NAME}.service"
systemctl restart "${APP_NAME}.service"

# 6. nginx ------------------------------------------------------------------
echo "==> Installing nginx site → ${NGINX_SITE_AVAIL}"
install -m 0644 "${SRC_DIR}/deploy/nginx-resume-checker.conf" "${NGINX_SITE_AVAIL}"
ln -sf "${NGINX_SITE_AVAIL}" "${NGINX_SITE_ENABL}"
# Disable default site if present to avoid port 80 clash
if [[ -L /etc/nginx/sites-enabled/default ]]; then
  rm -f /etc/nginx/sites-enabled/default
fi
nginx -t
systemctl reload nginx

# 7. Summary ----------------------------------------------------------------
echo
echo "============================================================"
echo " Resume Checker is installed."
echo
echo " Service : systemctl status ${APP_NAME}"
echo " Logs    : journalctl -u ${APP_NAME} -f"
echo " Nginx   : /var/log/nginx/${APP_NAME}.{access,error}.log"
echo " URL     : http://<this-vm-ip>/"
echo
echo " To enable Ollama AI tailoring:"
echo "   curl -fsSL https://ollama.com/install.sh | sh"
echo "   ollama pull llama3.1:8b"
echo "   sudo sed -i 's/^Environment=\"AI_PROVIDER=rule_based\"/#&/' ${SERVICE_FILE}"
echo "   sudo sed -i 's/^; Environment=\"AI_PROVIDER=ollama\"/Environment=\"AI_PROVIDER=ollama\"/' ${SERVICE_FILE}"
echo "   sudo systemctl daemon-reload && sudo systemctl restart ${APP_NAME}"
echo "============================================================"
