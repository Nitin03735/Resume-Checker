"""Tests for sections parser, rule-based tailor, and renderers."""

from __future__ import annotations

from analyzer.ai_tailor import tailor_resume
from analyzer.renderer_docx import render_docx
from analyzer.renderer_pdf import render_pdf
from analyzer.sections import (
    extract_contact,
    extract_name_title,
    extract_skills,
    parse_resume_sections,
)

SAMPLE_RESUME = """
Jane Doe
System Support Engineer
Bangalore, India  |  +91-9999999999  |  jane@example.com  |  linkedin.com/in/janedoe  |  github.com/janedoe

Professional Summary
2+ years working on Azure infrastructure and NOC operations with a focus on
automation and reliability.

Skills
Azure, Terraform, GitHub Actions, PowerShell, Python, PagerDuty, Jira

Professional Experience
System Support Engineer at Veradigm — Bengaluru          Jul 2023 – Present
• Patched 300+ Azure VMs monthly with 100% on-time completion
• Built GitHub Actions pipeline for pre-patch assessment
• Reduced MTTR by 25% through runbook automation

Education
B.Tech, Computer Science — Example University          2019 – 2023

Certifications
AZ-900 Microsoft Azure Fundamentals
"""


# ---------- sections ----------

def test_extract_contact():
    c = extract_contact(SAMPLE_RESUME)
    assert c["email"] == "jane@example.com"
    assert "9999999999" in c["phone"]
    assert "linkedin.com/in/janedoe" in c["linkedin"]
    assert "github.com/janedoe" in c["github"]


def test_extract_name_title():
    name, title = extract_name_title(SAMPLE_RESUME)
    assert name == "Jane Doe"
    assert "System Support" in title


def test_extract_skills():
    skills = extract_skills(["Azure, Terraform, GitHub Actions, Python"])
    assert "Azure" in skills
    assert "Terraform" in skills
    assert "GitHub Actions" in skills


def test_parse_sections_full():
    out = parse_resume_sections(SAMPLE_RESUME)
    assert out["name"] == "Jane Doe"
    assert "Azure" in out["skills"]
    assert out["experience"], "experience should be detected"
    role = out["experience"][0]
    assert "Veradigm" in role["org"] or "Veradigm" in role["role"]
    assert "Jul 2023" in role["dates"]
    assert any("300" in b for b in role["bullets"])


# ---------- rule-based tailor ----------

def test_rule_based_tailor_adds_missing_keywords():
    jd = "We need Kubernetes, Docker, Prometheus, Grafana, ArgoCD and Helm."
    t = tailor_resume(SAMPLE_RESUME, jd, provider="rule_based")
    assert t["name"] == "Jane Doe"
    low_skills = [s.lower() for s in t["skills"]]
    assert "kubernetes" in low_skills
    assert "docker" in low_skills
    assert "grafana" in low_skills
    assert any("Added" in c for c in t["changes"])


def test_rule_based_tailor_no_jd_keeps_resume():
    t = tailor_resume(SAMPLE_RESUME, "", provider="rule_based")
    assert t["name"] == "Jane Doe"


def test_rule_based_tailor_meta_fields():
    jd = "Kubernetes Docker"
    t = tailor_resume(SAMPLE_RESUME, jd, provider="rule_based")
    assert t["_meta"]["provider"] == "rule_based"
    assert t["_meta"]["added_skills_count"] >= 2


# ---------- renderers ----------

def _sample_tailored():
    return {
        "name": "Jane Doe",
        "title": "DevOps Engineer",
        "contact": {
            "email": "jane@example.com",
            "phone": "+91-9999999999",
            "linkedin": "linkedin.com/in/janedoe",
            "github": "github.com/janedoe",
            "location": "Bangalore, India",
        },
        "summary": "2+ years in Azure Cloud Operations and NOC automation.",
        "skills": ["Azure", "Terraform", "GitHub Actions", "Docker"],
        "experience": [{
            "role": "System Support Engineer",
            "org": "Veradigm",
            "location": "Bengaluru",
            "dates": "Jul 2023 – Present",
            "bullets": [
                "Patched 300+ Azure VMs monthly with 100% on-time completion",
                "Reduced MTTR by 25% through runbook automation",
            ],
        }],
        "projects": [{
            "name": "Azure VM Patching CI/CD",
            "stack": "GitHub Actions, PowerShell, Azure OIDC",
            "bullets": ["Tag-driven patching across subscriptions"],
        }],
        "education": [{"degree": "B.Tech CS", "institution": "Example Univ", "dates": "2019–2023"}],
        "certifications": ["AZ-900"],
        "changes": ["Added Kubernetes to Skills"],
    }


def test_render_docx_returns_bytes():
    buf = render_docx(_sample_tailored())
    data = buf.getvalue()
    assert len(data) > 2000  # a real docx is at least a few KB
    assert data[:2] == b"PK"  # docx = zip container


def test_render_pdf_returns_bytes():
    buf = render_pdf(_sample_tailored())
    data = buf.getvalue()
    assert len(data) > 1000
    assert data[:4] == b"%PDF"
