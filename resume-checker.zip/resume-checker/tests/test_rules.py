"""Unit tests for analyzer rules (no file IO — we fake the parsed context)."""

from __future__ import annotations

import pytest

from analyzer import rules
from analyzer.keywords import (
    detect_acronyms,
    extract_keywords,
    keyword_overlap,
)


def _ctx(text: str, *, pages=1, images=0, size_bytes=120_000, jd=""):
    return {
        "parsed": {
            "format": "pdf",
            "pages": pages,
            "text": text,
            "char_count": len(text),
            "word_count": len(text.split()),
            "has_text": bool(text.strip()),
            "fonts_used": ["Calibri"],
            "has_tables": False,
            "has_images": images > 0,
            "image_count": images,
            "metadata": {},
            "file_size_bytes": size_bytes,
            "errors": [],
        },
        "jd_text": jd,
    }


# ---------- parseability ----------

def test_text_extractable_passes_on_good_resume():
    ctx = _ctx(" ".join(["word"] * 300))
    r = rules.check_text_extractable(ctx)
    assert r["passed"] is True
    assert r["score"] == 10


def test_text_extractable_fails_when_empty():
    ctx = _ctx("")
    r = rules.check_text_extractable(ctx)
    assert r["passed"] is False


def test_page_count_sweet_spot():
    assert rules.check_page_count(_ctx("x", pages=1))["score"] == 5
    assert rules.check_page_count(_ctx("x", pages=2))["score"] == 5
    assert rules.check_page_count(_ctx("x", pages=3))["score"] == 3
    assert rules.check_page_count(_ctx("x", pages=5))["score"] == 0


def test_no_images_penalty():
    assert rules.check_no_images(_ctx("x", images=0))["score"] == 5
    assert rules.check_no_images(_ctx("x", images=1))["score"] == 2


def test_file_size_tiers():
    assert rules.check_file_size(_ctx("x", size_bytes=500_000))["score"] == 5
    assert rules.check_file_size(_ctx("x", size_bytes=3 * 1024 * 1024))["score"] == 3
    assert rules.check_file_size(_ctx("x", size_bytes=7 * 1024 * 1024))["score"] == 0


# ---------- structure ----------

def test_sections_full_credit():
    text = """
    Professional Summary
    ...
    Experience
    ...
    Skills
    ...
    Education
    ...
    Projects
    """
    r = rules.check_sections(_ctx(text))
    assert r["score"] == 20
    assert r["passed"] is True


def test_sections_missing_some():
    r = rules.check_sections(_ctx("Experience ... Skills ..."))
    assert r["score"] == 8
    assert r["passed"] is False


# ---------- contact ----------

def test_contact_full():
    text = "test@example.com +91-9999999999 linkedin.com/in/foo github.com/foo"
    r = rules.check_contact(_ctx(text))
    assert r["score"] == 10
    assert r["passed"] is True


def test_contact_partial():
    r = rules.check_contact(_ctx("test@example.com"))
    assert r["score"] == 3
    assert r["passed"] is False


# ---------- dates ----------

def test_date_format_good():
    r = rules.check_date_format(_ctx("Jul 2023 – Present and Jun 2021 – Jul 2023"))
    assert r["passed"] is True
    assert r["score"] == 5


def test_date_format_numeric_only():
    r = rules.check_date_format(_ctx("7/23 to 10/26"))
    assert r["score"] <= 1


def test_present_role_detected():
    assert rules.check_present_role(_ctx("Present"))["passed"] is True
    assert rules.check_present_role(_ctx("none"))["passed"] is False


# ---------- keywords ----------

def test_keywords_no_jd_full_marks():
    r = rules.check_keywords(_ctx("hello world"))
    assert r["score"] == 20


def test_keywords_partial_overlap():
    text = "Azure Terraform GitHub Actions Docker"
    jd = "We need Azure, AWS, Terraform, Docker, Kubernetes, Jenkins, Python"
    r = rules.check_keywords(_ctx(text, jd=jd))
    assert 0 < r["score"] < 20


def test_extract_keywords_skips_stopwords():
    kws = extract_keywords("We need a strong engineer with Azure and Docker.")
    assert "azure" in kws
    assert "docker" in kws
    assert "the" not in kws


def test_keyword_overlap_phrase():
    matched, missing = keyword_overlap(
        "Experienced with github actions and OIDC.",
        ["github actions", "terraform"],
    )
    assert "github actions" in matched
    assert "terraform" in missing


# ---------- metrics ----------

def test_metrics_good_bullets():
    text = """
    • Reduced patch time by 40% across 120 VMs
    • Delivered 100% monthly compliance over 18 months
    • Cut MTTR by 25 minutes
    • Shipped 5 production releases
    • Monitored 300+ servers
    """
    r = rules.check_metrics(_ctx(text))
    assert r["score"] == 10
    assert r["passed"] is True


def test_metrics_no_bullets():
    r = rules.check_metrics(_ctx("I did some work."))
    assert r["passed"] is False


# ---------- acronyms ----------

def test_acronyms_expansion_present():
    text = "I use RBAC (Role-Based Access Control) and CI/CD extensively."
    found = detect_acronyms(text)
    assert "RBAC" in found and found["RBAC"] is True


def test_acronyms_no_expansion():
    text = "Worked with AVD and AKS daily."
    r = rules.check_acronyms(_ctx(text))
    assert r["passed"] is False
    assert "AVD" in r["suggestion"] or "AKS" in r["suggestion"]


# ---------- integration ----------

def test_rules_registry_is_complete():
    """Every rule must return a well-formed dict."""
    ctx = _ctx("Experience Skills Education Summary Projects " +
               "test@x.com +91-9999999999 linkedin.com/in/foo " +
               "Jul 2023 – Present • Did 10 things • Delivered 50% faster")
    for rule in rules.ALL_RULES:
        r = rule(ctx)
        assert set(r.keys()) >= {
            "id", "label", "category", "passed", "score", "max",
            "detail", "suggestion",
        }
