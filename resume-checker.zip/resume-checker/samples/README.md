# Samples

Drop your `*.pdf` or `*.docx` resumes in this folder to test the checker.

**They are git-ignored** — nothing from this folder will ever be committed,
even if you accidentally run `git init` later. (See `../.gitignore`.)
