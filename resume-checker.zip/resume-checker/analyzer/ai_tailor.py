"""Pluggable AI resume-tailor.

Providers (chosen via AI_PROVIDER env var):
    rule_based  (default)  – no AI; keyword/metric heuristics
    ollama                 – local Ollama server; recommended for Linux VM
    openai                 – any OpenAI-compatible API

All providers return the same shape (``TailoredResume``) so the Flask
endpoints and renderers never care which backend ran.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any

import requests

from .keywords import extract_keywords, keyword_overlap
from .sections import parse_resume_sections

TAILORED_SCHEMA_HINT = """
{
  "name": "...",
  "title": "...",
  "contact": {"email": "...", "phone": "...", "linkedin": "...",
              "github": "...", "location": "..."},
  "summary": "3-4 sentence paragraph that works missing JD keywords in naturally",
  "skills": ["flat", "list", "of", "individual", "skills"],
  "experience": [
    {"role": "...", "org": "...", "location": "...", "dates": "...",
     "bullets": ["start with a strong verb", "include numbers/outcomes where plausible"]}
  ],
  "projects": [
    {"name": "...", "stack": "comma-separated tools",
     "bullets": ["..."]}
  ],
  "education": [
    {"degree": "...", "institution": "...", "dates": "..."}
  ],
  "certifications": ["..."],
  "changes": ["human-readable list of what you changed and why"]
}
"""

_SYSTEM_PROMPT = (
    "You are a senior technical resume writer. "
    "You tailor the candidate's resume to the given Job Description. "
    "You NEVER invent employers, titles, or dates that aren't already in "
    "the current resume. You preserve current employer, title and dates "
    "exactly. You rewrite bullets to be outcome-oriented and insert "
    "missing JD keywords naturally into the Summary, Skills and (where "
    "plausible) Experience bullets. If a specific metric is unknown, use "
    "a bracketed placeholder like [N] or [NN%] rather than fabricating."
)


def _user_prompt(resume_text: str, jd_text: str, missing_kw: list[str]) -> str:
    return (
        "CURRENT RESUME:\n"
        f"{resume_text}\n\n"
        "TARGET JOB DESCRIPTION:\n"
        f"{jd_text}\n\n"
        f"MISSING KEYWORDS from the JD: {', '.join(missing_kw[:30]) or '(none)'}\n\n"
        "Return ONLY valid JSON matching this schema (no prose, no markdown):\n"
        f"{TAILORED_SCHEMA_HINT}"
    )


# -------- entry point ------------------------------------------------------

def tailor_resume(
    resume_text: str,
    jd_text: str,
    *,
    provider: str | None = None,
    model: str | None = None,
) -> dict[str, Any]:
    """Return a TailoredResume dict for rendering + download."""
    provider = (provider or os.environ.get("AI_PROVIDER") or "rule_based").lower()
    model = model or os.environ.get("AI_MODEL") or ""

    # Pre-compute keyword gap so every provider gets the same signal
    jd_keywords = extract_keywords(jd_text or "", max_keywords=50)
    _, missing = keyword_overlap(resume_text, jd_keywords)

    if provider == "ollama":
        try:
            return _tailor_with_ollama(resume_text, jd_text, missing, model)
        except Exception as exc:
            return _rule_based(resume_text, jd_text, missing,
                               error=f"Ollama failed: {exc}")
    if provider == "openai":
        try:
            return _tailor_with_openai(resume_text, jd_text, missing, model)
        except Exception as exc:
            return _rule_based(resume_text, jd_text, missing,
                               error=f"OpenAI failed: {exc}")
    return _rule_based(resume_text, jd_text, missing)


# -------- rule-based (zero-AI) ---------------------------------------------

def _rule_based(resume_text: str, jd_text: str, missing_kw: list[str],
                error: str | None = None) -> dict[str, Any]:
    parsed = parse_resume_sections(resume_text)

    changes: list[str] = []
    if error:
        changes.append(f"⚠ AI provider error — fell back to rule-based: {error}")

    # 1) Skills: add missing keywords that are plausible technical terms
    original_skills = parsed["skills"][:]
    added = []
    for kw in missing_kw:
        if 2 <= len(kw) <= 32 and kw.lower() not in {s.lower() for s in parsed["skills"]}:
            parsed["skills"].append(_normalise_skill(kw))
            added.append(kw)
    if added:
        changes.append(
            f"Added {len(added)} missing JD keywords to Skills: "
            f"{', '.join(added[:10])}{'…' if len(added) > 10 else ''}"
        )

    # 2) Summary: ensure it mentions the top-3 missing keywords
    top3 = [k for k in missing_kw[:3]]
    summary = parsed["summary"] or (
        "Results-oriented engineer with proven experience across the "
        "technologies and workflows below."
    )
    if top3:
        inject = ", ".join(top3)
        if not any(k.lower() in summary.lower() for k in top3):
            summary = (
                summary.rstrip(". ")
                + f". Hands-on with {inject} and the broader stack listed in Skills."
            )
            changes.append(f"Rewrote Summary to include: {inject}.")

    # 3) Experience bullets: flag ones without numbers
    weak = 0
    for role in parsed["experience"]:
        for b in role["bullets"]:
            if not re.search(r"\d", b):
                weak += 1
    if weak:
        changes.append(
            f"⚠ {weak} experience bullet(s) have no numbers/outcomes. "
            "Add measurable results (%, counts, time saved, SLA)."
        )

    # 4) Carry contact as-is; try to synthesise title if missing
    title = parsed["title"] or "Cloud / DevOps Engineer"

    tailored = {
        "name": parsed["name"] or "[Your Name]",
        "title": title,
        "contact": {
            "email": parsed["contact"].get("email", "[email]"),
            "phone": parsed["contact"].get("phone", "[phone]"),
            "linkedin": parsed["contact"].get("linkedin", ""),
            "github": parsed["contact"].get("github", ""),
            "location": "",
        },
        "summary": summary,
        "skills": parsed["skills"],
        "experience": parsed["experience"],
        "projects": parsed["projects"],
        "education": [
            {"degree": line, "institution": "", "dates": ""}
            for line in parsed["education"]
        ],
        "certifications": parsed["certifications"],
        "changes": changes or [
            "No material gaps detected vs. this JD — resume used as-is."
        ],
        "_meta": {
            "provider": "rule_based",
            "original_skills_count": len(original_skills),
            "added_skills_count": len(added),
            "weak_bullets": weak,
        },
    }
    return tailored


def _normalise_skill(kw: str) -> str:
    specials = {
        "ci/cd": "CI/CD",
        "aws": "AWS",
        "gcp": "GCP",
        "sre": "SRE",
        "noc": "NOC",
        "api": "API",
        "sql": "SQL",
        "oidc": "OIDC",
        "iac": "Infrastructure as Code (IaC)",
        "rbac": "RBAC",
        "aks": "AKS",
        "acr": "ACR",
    }
    low = kw.lower().strip()
    return specials.get(low, kw.strip().capitalize())


# -------- Ollama -----------------------------------------------------------

def _tailor_with_ollama(resume_text: str, jd_text: str,
                        missing_kw: list[str], model: str) -> dict[str, Any]:
    url = os.environ.get("OLLAMA_URL", "http://localhost:11434").rstrip("/")
    model = model or "llama3.1:8b"
    body = {
        "model": model,
        "format": "json",
        "stream": False,
        "options": {"temperature": 0.3},
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": _user_prompt(resume_text, jd_text, missing_kw)},
        ],
    }
    r = requests.post(f"{url}/api/chat", json=body, timeout=180)
    r.raise_for_status()
    data = r.json()
    content = data.get("message", {}).get("content") or data.get("response") or ""
    parsed = _safe_json(content)
    parsed.setdefault("_meta", {})["provider"] = f"ollama/{model}"
    return parsed


# -------- OpenAI-compatible ------------------------------------------------

def _tailor_with_openai(resume_text: str, jd_text: str,
                        missing_kw: list[str], model: str) -> dict[str, Any]:
    base = os.environ.get("OPENAI_API_BASE", "https://api.openai.com/v1").rstrip("/")
    key = os.environ.get("OPENAI_API_KEY", "")
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    model = model or os.environ.get("AI_MODEL") or "gpt-4o-mini"
    body = {
        "model": model,
        "response_format": {"type": "json_object"},
        "temperature": 0.3,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": _user_prompt(resume_text, jd_text, missing_kw)},
        ],
    }
    headers = {
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
    }
    r = requests.post(f"{base}/chat/completions", json=body,
                      headers=headers, timeout=120)
    r.raise_for_status()
    data = r.json()
    content = data["choices"][0]["message"]["content"]
    parsed = _safe_json(content)
    parsed.setdefault("_meta", {})["provider"] = f"openai/{model}"
    return parsed


# -------- JSON cleanup -----------------------------------------------------

def _safe_json(raw: str) -> dict[str, Any]:
    """LLMs sometimes wrap JSON in prose/markdown. Rescue it."""
    if not raw:
        return {}
    raw = raw.strip()
    # strip ```json fences
    raw = re.sub(r"^```(?:json)?\s*", "", raw)
    raw = re.sub(r"\s*```$", "", raw)
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # grab outermost { ... } block
        m = re.search(r"\{.*\}", raw, flags=re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    raise ValueError("Model did not return valid JSON.")
