"""PDF (and DOCX) resume parser.

Extracts: full text, page count, fonts, images, tables, metadata, char count.
Everything downstream rules use is built from this parsed payload.
"""

from __future__ import annotations

import os
from typing import Any

import pdfplumber
from docx import Document


def parse_resume(file_path: str) -> dict[str, Any]:
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".pdf":
        return _parse_pdf(file_path)
    if ext == ".docx":
        return _parse_docx(file_path)
    return _empty_result(f"Unsupported file type: {ext}. Use .pdf or .docx")


def _empty_result(error: str | None = None) -> dict[str, Any]:
    return {
        "format": None,
        "pages": 0,
        "text": "",
        "char_count": 0,
        "word_count": 0,
        "has_text": False,
        "fonts_used": [],
        "has_tables": False,
        "has_images": False,
        "image_count": 0,
        "metadata": {},
        "file_size_bytes": 0,
        "errors": [error] if error else [],
    }


def _parse_pdf(file_path: str) -> dict[str, Any]:
    result = _empty_result()
    result["format"] = "pdf"
    result["file_size_bytes"] = os.path.getsize(file_path)
    try:
        with pdfplumber.open(file_path) as pdf:
            result["pages"] = len(pdf.pages)
            result["metadata"] = _clean_metadata(pdf.metadata or {})
            all_text: list[str] = []
            fonts: set[str] = set()
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                all_text.append(page_text)
                for ch in getattr(page, "chars", []) or []:
                    fname = ch.get("fontname")
                    if fname:
                        # strip subset prefix like "ABCDEF+Calibri"
                        fname_clean = fname.split("+", 1)[-1]
                        fonts.add(fname_clean)
                imgs = page.images or []
                result["image_count"] += len(imgs)
                if imgs:
                    result["has_images"] = True
                try:
                    if page.find_tables():
                        result["has_tables"] = True
                except Exception:
                    pass
            text = "\n".join(all_text)
            result["text"] = text
            result["char_count"] = len(text)
            result["word_count"] = len(text.split())
            result["has_text"] = bool(text.strip())
            result["fonts_used"] = sorted(fonts)
    except Exception as exc:  # pragma: no cover - defensive
        result["errors"].append(str(exc))
    return result


def _parse_docx(file_path: str) -> dict[str, Any]:
    result = _empty_result()
    result["format"] = "docx"
    result["file_size_bytes"] = os.path.getsize(file_path)
    try:
        doc = Document(file_path)
        paragraphs = [p.text for p in doc.paragraphs]
        for table in doc.tables:
            result["has_tables"] = True
            for row in table.rows:
                for cell in row.cells:
                    paragraphs.append(cell.text)
        text = "\n".join(paragraphs)
        result["text"] = text
        result["char_count"] = len(text)
        result["word_count"] = len(text.split())
        result["has_text"] = bool(text.strip())
        # pages: docx has no reliable page count without rendering; estimate
        result["pages"] = max(1, round(result["word_count"] / 500))
        # fonts: inspect runs
        fonts: set[str] = set()
        for para in doc.paragraphs:
            for run in para.runs:
                if run.font and run.font.name:
                    fonts.add(run.font.name)
        result["fonts_used"] = sorted(fonts)
        # images: inline shapes
        try:
            result["image_count"] = len(doc.inline_shapes)
            result["has_images"] = result["image_count"] > 0
        except Exception:
            pass
    except Exception as exc:  # pragma: no cover
        result["errors"].append(str(exc))
    return result


def _clean_metadata(meta: dict) -> dict:
    out = {}
    for k, v in meta.items():
        try:
            out[str(k)] = str(v)
        except Exception:
            continue
    return out
