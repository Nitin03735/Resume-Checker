"""Render a TailoredResume dict to a PDF (BytesIO) using fpdf2.

Pure-Python; no external binaries required (works on any Linux VM).
"""

from __future__ import annotations

import io
from typing import Any

from fpdf import FPDF

ACCENT = (7, 59, 156)
INK = (21, 32, 43)
MUTED = (75, 90, 107)


class ResumePDF(FPDF):
    def header(self):  # suppress default
        return

    def footer(self):  # suppress default
        return


def _h1(pdf: ResumePDF, text: str):
    pdf.set_font("Helvetica", "B", 20)
    pdf.set_text_color(*INK)
    pdf.cell(0, 9, text, ln=True)


def _title(pdf: ResumePDF, text: str):
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(*ACCENT)
    pdf.cell(0, 6, text, ln=True)


def _h2(pdf: ResumePDF, text: str):
    pdf.ln(2)
    pdf.set_font("Helvetica", "B", 11)
    pdf.set_text_color(*ACCENT)
    pdf.cell(0, 6, text.upper(), ln=True)
    y = pdf.get_y()
    pdf.set_draw_color(*ACCENT)
    pdf.set_line_width(0.3)
    pdf.line(pdf.l_margin, y, pdf.w - pdf.r_margin, y)
    pdf.ln(2)


def _body(pdf: ResumePDF, text: str, *, size=10.5, color=INK, italic=False, bold=False):
    style = ("B" if bold else "") + ("I" if italic else "")
    pdf.set_font("Helvetica", style, size)
    pdf.set_text_color(*color)
    pdf.multi_cell(0, 5.2, text)


def _bullet(pdf: ResumePDF, text: str):
    pdf.set_font("Helvetica", "", 10.5)
    pdf.set_text_color(*INK)
    # draw bullet marker + indented text
    x_start = pdf.get_x()
    pdf.cell(5, 5.2, "•", ln=0)
    pdf.set_x(x_start + 5)
    pdf.multi_cell(0, 5.2, text)


def _rule(pdf: ResumePDF, color=ACCENT):
    y = pdf.get_y()
    r, g, b = color
    pdf.set_draw_color(r, g, b)
    pdf.set_line_width(0.3)
    pdf.line(pdf.l_margin, y, pdf.w - pdf.r_margin, y)
    pdf.ln(1)


def render_pdf(tailored: dict[str, Any]) -> io.BytesIO:
    pdf = ResumePDF(orientation="P", unit="mm", format="A4")
    pdf.set_margins(left=16, top=14, right=16)
    pdf.set_auto_page_break(auto=True, margin=14)
    pdf.add_page()

    # ---- header ----
    _h1(pdf, tailored.get("name") or "[Your Name]")
    if tailored.get("title"):
        _title(pdf, tailored["title"])

    contact = tailored.get("contact") or {}
    bits = [contact.get("location"), contact.get("phone"),
            contact.get("email"), contact.get("linkedin"),
            contact.get("github")]
    bits = [b for b in bits if b]
    if bits:
        _body(pdf, "   |   ".join(bits), size=9.5, color=MUTED)
        _rule(pdf)

    # ---- summary ----
    if tailored.get("summary"):
        _h2(pdf, "Professional Summary")
        _body(pdf, tailored["summary"])

    # ---- skills ----
    skills = tailored.get("skills") or []
    if skills:
        _h2(pdf, "Skills")
        _body(pdf, " · ".join(skills))

    # ---- experience ----
    exp = tailored.get("experience") or []
    if exp:
        _h2(pdf, "Professional Experience")
        for role in exp:
            name = role.get("role") or ""
            dates = role.get("dates") or ""
            if name or dates:
                pdf.set_font("Helvetica", "B", 11.5)
                pdf.set_text_color(*INK)
                # title left + dates right
                w_right = pdf.get_string_width(dates) + 2
                page_w = pdf.w - pdf.l_margin - pdf.r_margin
                pdf.cell(page_w - w_right, 5.2, name, ln=0)
                pdf.set_font("Helvetica", "I", 10)
                pdf.set_text_color(*MUTED)
                pdf.cell(w_right, 5.2, dates, ln=1, align="R")

            org_loc = "  —  ".join(x for x in [role.get("org"), role.get("location")] if x)
            if org_loc:
                _body(pdf, org_loc, size=10, color=MUTED, italic=True)

            for b in role.get("bullets") or []:
                _bullet(pdf, b)
            pdf.ln(1)

    # ---- projects ----
    projects = tailored.get("projects") or []
    if projects:
        _h2(pdf, "Highlighted Projects")
        for pr in projects:
            name = pr.get("name") or pr.get("role") or ""
            if name:
                _body(pdf, name, bold=True, size=11)
            stack = pr.get("stack")
            if stack:
                _body(pdf, stack, size=9.5, color=MUTED, italic=True)
            for b in pr.get("bullets") or []:
                _bullet(pdf, b)
            pdf.ln(1)

    # ---- education ----
    edu = tailored.get("education") or []
    if edu:
        _h2(pdf, "Education")
        for e in edu:
            if isinstance(e, str):
                _body(pdf, e)
            else:
                parts = [e.get("degree", ""), e.get("institution", ""), e.get("dates", "")]
                line = "   —   ".join(x for x in parts if x)
                _body(pdf, line)

    # ---- certifications ----
    certs = tailored.get("certifications") or []
    if certs:
        _h2(pdf, "Certifications")
        for c in certs:
            _bullet(pdf, c)

    # fpdf2 returns bytes/bytearray from .output()
    out = pdf.output()
    if isinstance(out, (bytes, bytearray)):
        buf = io.BytesIO(bytes(out))
    else:  # pragma: no cover (older fpdf2 behaviour)
        buf = io.BytesIO(out.encode("latin-1"))
    buf.seek(0)
    return buf
