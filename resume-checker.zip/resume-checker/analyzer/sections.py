"""Lightweight resume text → structured sections parser.

This is intentionally heuristic (not NLP-heavy) so it has zero extra deps.
Downstream code (rule-based tailor, LLM prompts, renderers) uses the output.
"""

from __future__ import annotations

import re
from typing import Any

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(r"(\+?\d[\d\-\s()]{7,}\d)")
_LINKEDIN_RE = re.compile(r"linkedin\.com/in/[A-Za-z0-9\-_%]+", re.IGNORECASE)
_GITHUB_RE = re.compile(r"github\.com/[A-Za-z0-9\-_%]+", re.IGNORECASE)
_URL_RE = re.compile(r"https?://\S+")

# Section header candidates (match line that is mostly this word).
SECTION_HEADERS = {
    "summary": [
        r"^\s*(professional\s+summary|summary|profile|objective|about\s+me)\s*:?\s*$",
    ],
    "skills": [
        r"^\s*(core\s+skills|technical\s+skills|key\s+skills|skills)\s*:?\s*$",
    ],
    "experience": [
        r"^\s*(professional\s+experience|work\s+experience|experience|employment)\s*:?\s*$",
    ],
    "projects": [
        r"^\s*(projects|highlighted\s+projects|key\s+projects|personal\s+projects)\s*:?\s*$",
    ],
    "education": [
        r"^\s*(education|academics?|qualifications?)\s*:?\s*$",
    ],
    "certifications": [
        r"^\s*(certifications?|licenses?|courses?)\s*:?\s*$",
    ],
    "soft": [
        r"^\s*(soft\s+skills|strengths)\s*:?\s*$",
    ],
}

# Compile once
_COMPILED = {
    sec: [re.compile(p, re.IGNORECASE) for p in pats]
    for sec, pats in SECTION_HEADERS.items()
}


def _which_section(line: str) -> str | None:
    for sec, pats in _COMPILED.items():
        for p in pats:
            if p.match(line):
                return sec
    return None


def extract_contact(text: str) -> dict[str, str]:
    out: dict[str, str] = {}
    m = _EMAIL_RE.search(text)
    if m:
        out["email"] = m.group(0)
    m = _PHONE_RE.search(text)
    if m:
        out["phone"] = m.group(0).strip()
    m = _LINKEDIN_RE.search(text)
    if m:
        out["linkedin"] = m.group(0)
    m = _GITHUB_RE.search(text)
    if m:
        out["github"] = m.group(0)
    return out


def extract_name_title(text: str) -> tuple[str, str]:
    """Heuristic: first non-empty, non-contact line is the name; the next
    short line that isn't contact-like is treated as the title."""
    name, title = "", ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if _EMAIL_RE.search(line) or _PHONE_RE.search(line) or _URL_RE.search(line):
            continue
        if not name:
            name = line[:80]
            continue
        # title candidate: short-ish, has letters, no bullet
        if 3 <= len(line) <= 80 and not line.startswith(("•", "-", "*")):
            title = line
            break
    return name, title


def split_sections(text: str) -> dict[str, list[str]]:
    """Return {section_name: [lines]} using header heuristics."""
    sections: dict[str, list[str]] = {"_preamble": []}
    current = "_preamble"
    for raw in text.splitlines():
        line = raw.rstrip()
        sec = _which_section(line.strip())
        if sec:
            current = sec
            sections.setdefault(current, [])
            continue
        sections.setdefault(current, []).append(line)
    return sections


_BULLET_RE = re.compile(r"^\s*(?:[\u2022\-\*\u25E6\u2023\u2043\u2219]|\d+\.)\s+(.+)$")


def extract_bullets(lines: list[str]) -> list[str]:
    """Pull out bullet lines; strip markers."""
    out: list[str] = []
    for ln in lines:
        m = _BULLET_RE.match(ln)
        if m:
            out.append(m.group(1).strip())
    return out


_SKILL_SPLIT_RE = re.compile(r"[·,|;/•\n]+")


def extract_skills(lines: list[str]) -> list[str]:
    """From a Skills section, flatten comma/pipe/bullet-separated items."""
    joined = " ".join(ln for ln in lines if ln.strip())
    # strip "Category:" prefixes
    joined = re.sub(r"^[A-Za-z &/]+:", "", joined, flags=re.MULTILINE)
    parts = [p.strip() for p in _SKILL_SPLIT_RE.split(joined)]
    skills, seen = [], set()
    for p in parts:
        if not p or len(p) < 2 or len(p) > 60:
            continue
        key = p.lower()
        if key in seen:
            continue
        seen.add(key)
        skills.append(p)
    return skills[:60]


_DATE_RANGE_RE = re.compile(
    r"((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{4}"
    r"\s*[\-–—]\s*"
    r"(?:(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{4}|Present|Current|Till Date))",
    re.IGNORECASE,
)


def extract_experience(lines: list[str]) -> list[dict[str, Any]]:
    """Very light experience parser.

    Group logic: whenever we see a date-range on (or near) a line, treat it
    as a new role header. Bullets that follow belong to that role.
    """
    roles: list[dict[str, Any]] = []
    current: dict[str, Any] | None = None
    pending_header: list[str] = []

    for raw in lines:
        line = raw.rstrip()
        if not line.strip():
            if pending_header and current:
                pending_header = []
            continue
        m = _DATE_RANGE_RE.search(line)
        bullet_m = _BULLET_RE.match(line)

        if m and not bullet_m:
            # finalize previous
            if current:
                roles.append(current)
            dates = m.group(1)
            # Everything on the line other than the date = title / org
            head = _DATE_RANGE_RE.sub("", line).strip(" -–—|•\t")
            # title + org may be split by ' at ', ' - ', '|', '—'
            role_title, org = head, ""
            for sep in [" at ", " @ ", " — ", " – ", " - ", " | "]:
                if sep in head:
                    role_title, org = head.split(sep, 1)
                    break
            current = {
                "role": role_title.strip() or (pending_header[-1] if pending_header else ""),
                "org": org.strip(),
                "location": "",
                "dates": dates.strip(),
                "bullets": [],
            }
            pending_header = []
        elif bullet_m:
            if not current:
                current = {"role": "", "org": "", "location": "", "dates": "", "bullets": []}
            current["bullets"].append(bullet_m.group(1).strip())
        else:
            pending_header.append(line.strip())

    if current:
        roles.append(current)
    return roles


def parse_resume_sections(text: str) -> dict[str, Any]:
    """Top-level parser → structured resume dict used downstream."""
    name, title = extract_name_title(text)
    contact = extract_contact(text)
    secs = split_sections(text)

    summary = " ".join(
        ln.strip() for ln in secs.get("summary", []) if ln.strip()
    ).strip()
    skills = extract_skills(secs.get("skills", []))
    experience = extract_experience(secs.get("experience", []))
    projects = extract_experience(secs.get("projects", []))
    education_lines = [ln.strip() for ln in secs.get("education", []) if ln.strip()]
    certifications = [ln.strip() for ln in secs.get("certifications", []) if ln.strip()]

    return {
        "name": name,
        "title": title,
        "contact": contact,
        "summary": summary,
        "skills": skills,
        "experience": experience,
        "projects": projects,
        "education": education_lines,
        "certifications": certifications,
        "raw_sections": {k: "\n".join(v) for k, v in secs.items()},
    }
