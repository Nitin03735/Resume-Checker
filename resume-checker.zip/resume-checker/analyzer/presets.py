"""Preset Job Descriptions by role.

These are compact JDs modelled on common 2024-26 Indian/global JDs for the
roles below. Users can pick a preset instead of pasting their own JD, so the
tool works out of the box.
"""

from __future__ import annotations

PRESETS: dict[str, dict] = {
    "devops_engineer": {
        "label": "DevOps Engineer (0-3 yrs)",
        "jd": (
            "Looking for a DevOps Engineer with hands-on experience in "
            "Azure, AWS, Terraform, GitHub Actions, Jenkins, Docker, Kubernetes, "
            "Linux, Bash, Python, Git, CI/CD pipelines, Infrastructure as Code, "
            "Helm, Ansible, Prometheus, Grafana, ELK, YAML, REST APIs, OIDC, "
            "RBAC, networking, DNS, load balancer, Nginx, monitoring, logging, "
            "incident response, on-call, troubleshooting, Agile, Jira."
        ),
    },
    "cloud_support_engineer": {
        "label": "Cloud Support Engineer (Azure)",
        "jd": (
            "Cloud Support Engineer with strong Azure skills: Azure VM, Azure "
            "Virtual Desktop, AVD, session host, Azure Monitor, Log Analytics, "
            "Azure Policy, RBAC, Key Vault, networking, VPN, ExpressRoute, "
            "troubleshooting, Windows Server, Active Directory, PowerShell, "
            "patching, update management, incident, ticketing, Jira, "
            "ServiceNow, SLA, on-call, runbook, documentation."
        ),
    },
    "sre_engineer": {
        "label": "Site Reliability Engineer (SRE)",
        "jd": (
            "SRE with Kubernetes, AKS, EKS, Prometheus, Grafana, Loki, "
            "OpenTelemetry, PagerDuty, Terraform, GitHub Actions, GitOps, "
            "ArgoCD, Flux, Helm, Python, Go, Bash, incident response, SLO, "
            "SLI, error budget, chaos engineering, Linux, networking, CI/CD, "
            "observability, logging, tracing, alerting, on-call, blameless "
            "postmortem, reliability, performance."
        ),
    },
    "noc_engineer": {
        "label": "NOC Engineer (24x7 Operations)",
        "jd": (
            "NOC Engineer for 24x7 operations: PagerDuty, ServiceNow, Jira, "
            "Slack, Azure, AWS, monitoring, alerting, incident triage, "
            "ticketing, escalation, Windows Server, Linux, Active Directory, "
            "patching, Session Host, VPN, DNS, networking, Grafana, Prometheus, "
            "runbook, shift, handover, SLA, MTTA, MTTR, change management, "
            "communication, documentation."
        ),
    },
    "junior_cloud_devops": {
        "label": "Junior Cloud / DevOps (0-2 yrs)",
        "jd": (
            "Entry level Cloud / DevOps role: Azure or AWS fundamentals, "
            "Terraform, Git, GitHub Actions, Docker basics, Linux, Bash, "
            "Python scripting, YAML, REST API, Jira, Agile, troubleshooting, "
            "monitoring, logging, on-call shadowing, documentation, "
            "willingness to learn Kubernetes and Helm."
        ),
    },
}


def list_presets() -> list[dict]:
    return [{"id": pid, "label": p["label"]} for pid, p in PRESETS.items()]


def get_preset_jd(preset_id: str) -> str | None:
    p = PRESETS.get(preset_id)
    return p["jd"] if p else None
