"""Resume analyzer package.

Modules:
    parser        - extract text/metadata/fonts/images from a resume file
    sections      - heuristic resume text -> structured sections
    keywords      - keyword/acronym helpers
    presets       - preset job descriptions per role
    rules         - individual rule-check functions
    scorer        - orchestrator that runs rules and builds the final payload
    ai_tailor     - pluggable AI tailor (rule_based / ollama / openai)
    renderer_docx - render tailored resume to .docx (python-docx)
    renderer_pdf  - render tailored resume to .pdf  (fpdf2)
"""

from .ai_tailor import tailor_resume
from .renderer_docx import render_docx
from .renderer_pdf import render_pdf
from .scorer import analyze_resume

__all__ = [
    "analyze_resume",
    "tailor_resume",
    "render_docx",
    "render_pdf",
]
