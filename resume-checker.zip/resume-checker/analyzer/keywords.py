"""Keyword + acronym helpers for the rule engine."""

from __future__ import annotations

import re

# Common tech acronyms where ATS keyword dictionaries often index only one form.
# Expansions are shown as "ACRONYM (EXPANSION)".
ACRONYM_EXPANSIONS: dict[str, str] = {
    "AVD": "Azure Virtual Desktop",
    "AKS": "Azure Kubernetes Service",
    "ACR": "Azure Container Registry",
    "RBAC": "Role-Based Access Control",
    "PIM": "Privileged Identity Management",
    "OIDC": "OpenID Connect",
    "CI/CD": "Continuous Integration / Continuous Delivery",
    "IaC": "Infrastructure as Code",
    "SRE": "Site Reliability Engineering",
    "NOC": "Network Operations Center",
    "SOC": "Security Operations Center",
    "VPC": "Virtual Private Cloud",
    "VPN": "Virtual Private Network",
    "VM": "Virtual Machine",
    "CDN": "Content Delivery Network",
    "DNS": "Domain Name System",
    "DAST": "Dynamic Application Security Testing",
    "SAST": "Static Application Security Testing",
    "SLA": "Service Level Agreement",
    "SLO": "Service Level Objective",
    "KPI": "Key Performance Indicator",
    "RPO": "Recovery Point Objective",
    "RTO": "Recovery Time Objective",
    "MFA": "Multi-Factor Authentication",
    "SSO": "Single Sign-On",
    "CVE": "Common Vulnerabilities and Exposures",
    "API": "Application Programming Interface",
    "REST": "Representational State Transfer",
    "JVM": "Java Virtual Machine",
    "SQL": "Structured Query Language",
    "HPA": "Horizontal Pod Autoscaler",
    "RMM": "Remote Monitoring and Management",
    "ITIL": "Information Technology Infrastructure Library",
    "RPA": "Robotic Process Automation",
}

# Stop-words we never treat as "skills"
_STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "then", "else",
    "for", "to", "of", "in", "on", "with", "as", "by", "at", "is",
    "are", "was", "were", "be", "been", "being", "it", "its",
    "this", "that", "these", "those", "we", "our", "you", "your",
    "they", "their", "will", "shall", "can", "may", "should",
    "must", "have", "has", "had", "do", "does", "did", "from",
    "job", "role", "work", "team", "experience", "year", "years",
    "required", "preferred", "plus", "nice", "good", "strong",
    "ability", "etc", "including",
}


_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9+#./-]{1,24}")


def tokenize(text: str) -> list[str]:
    """Lowercase word-ish tokens; keeps items like `ci/cd`, `c++`, `c#`."""
    if not text:
        return []
    return [t.lower() for t in _TOKEN_RE.findall(text)]


def extract_keywords(text: str, max_keywords: int = 60) -> list[str]:
    """Rough JD keyword extraction: unique tokens, no stopwords, ranked by
    first-appearance order (good enough for a lightweight local tool)."""
    seen: dict[str, None] = {}
    for tok in tokenize(text):
        if tok in _STOPWORDS or len(tok) < 2:
            continue
        if tok.isdigit():
            continue
        if tok not in seen:
            seen[tok] = None
        if len(seen) >= max_keywords:
            break
    return list(seen.keys())


def keyword_overlap(resume_text: str, jd_keywords: list[str]) -> tuple[list[str], list[str]]:
    """Return (matched, missing) keyword lists."""
    if not jd_keywords:
        return [], []
    tokens = set(tokenize(resume_text))
    # Also index 2-grams for things like "github actions", "azure devops"
    text_lower = (resume_text or "").lower()
    matched: list[str] = []
    missing: list[str] = []
    for kw in jd_keywords:
        kw_l = kw.lower().strip()
        if not kw_l:
            continue
        if " " in kw_l or "/" in kw_l or "-" in kw_l:
            # phrase – substring match
            if kw_l in text_lower:
                matched.append(kw)
            else:
                missing.append(kw)
        else:
            if kw_l in tokens:
                matched.append(kw)
            else:
                missing.append(kw)
    return matched, missing


def detect_acronyms(text: str) -> dict[str, bool]:
    """For each known acronym present in the text, report whether its
    expansion is also present somewhere (case-insensitive)."""
    text_lower = (text or "").lower()
    result: dict[str, bool] = {}
    for acro, expansion in ACRONYM_EXPANSIONS.items():
        # Word-boundary match for the acronym itself
        if re.search(rf"\b{re.escape(acro)}\b", text, flags=re.IGNORECASE):
            result[acro] = expansion.lower() in text_lower
    return result
