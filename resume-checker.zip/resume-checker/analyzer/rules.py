"""Individual rule checks.

Each check accepts a context dict and returns a Check record:

    {
      "id": str,          # stable id
      "label": str,       # short human label
      "category": str,    # one of CATEGORIES
      "passed": bool,
      "score": int,       # earned
      "max": int,         # possible
      "detail": str,      # what we found
      "suggestion": str,  # how to fix if not full
    }

The scorer orchestrates these and sums the result per category.
"""

from __future__ import annotations

import re
from typing import Any

from .keywords import detect_acronyms, extract_keywords, keyword_overlap

# ---- category weights (sum = 100) -----------------------------------------
CATEGORIES = {
    "parseability": 25,
    "structure": 20,
    "contact": 10,
    "dates_format": 10,
    "keywords": 20,
    "metrics": 10,
    "acronyms": 5,
}


# ---- helpers ---------------------------------------------------------------

def _check(id_, label, category, passed, score, max_, detail, suggestion=""):
    return {
        "id": id_,
        "label": label,
        "category": category,
        "passed": bool(passed),
        "score": int(score),
        "max": int(max_),
        "detail": detail,
        "suggestion": suggestion if not passed else "",
    }


_SAFE_FONTS = {
    "calibri", "arial", "helvetica", "times", "times new roman", "georgia",
    "cambria", "garamond", "verdana", "tahoma", "palatino", "roboto",
    "open sans", "lato", "source sans pro", "noto sans",
}

_STANDARD_SECTIONS = {
    "summary": [r"\bsummary\b", r"\bprofessional\s+summary\b", r"\bprofile\b", r"\bobjective\b"],
    "experience": [r"\bexperience\b", r"\bwork\s+experience\b", r"\bprofessional\s+experience\b", r"\bemployment\b"],
    "education": [r"\beducation\b", r"\bacademic(s)?\b", r"\bqualification(s)?\b"],
    "skills": [r"\bskills\b", r"\btechnical\s+skills\b", r"\bcore\s+skills\b", r"\bkey\s+skills\b"],
    "projects_or_certs": [r"\bprojects\b", r"\bcertifications?\b", r"\bachievements\b"],
}


# ---- A. Parseability (25) --------------------------------------------------

def check_text_extractable(ctx) -> dict:
    p = ctx["parsed"]
    passed = p["has_text"] and p["word_count"] >= 150
    detail = f"Extracted {p['word_count']} words from {p['pages']} page(s)."
    return _check(
        "text_extractable", "Text is extractable", "parseability",
        passed, 10 if passed else 0, 10, detail,
        "If 0 words were extracted, the file is likely a scanned image. "
        "Save/export as a text-based PDF from Word or Google Docs."
    )


def check_page_count(ctx) -> dict:
    p = ctx["parsed"]
    pages = p["pages"]
    if 1 <= pages <= 2:
        return _check("page_count", "Page count (1-2 pages)", "parseability",
                      True, 5, 5, f"{pages} page(s).")
    if pages == 3:
        return _check("page_count", "Page count", "parseability",
                      True, 3, 5, f"{pages} pages (acceptable for 10+ yrs).",
                      "Trim to 2 pages unless you have 10+ years of experience.")
    return _check("page_count", "Page count", "parseability",
                  False, 0, 5, f"{pages} pages.",
                  "Trim to 1 page (0-3 yrs) or 2 pages (3-10 yrs).")


def check_no_images(ctx) -> dict:
    p = ctx["parsed"]
    if not p["has_images"]:
        return _check("no_images", "No images / photos", "parseability",
                      True, 5, 5, "No embedded images detected.")
    return _check("no_images", "No images / photos", "parseability",
                  False, 2, 5,
                  f"{p['image_count']} image(s) detected.",
                  "Remove photos, logos, and icon graphics. ATS parsers can "
                  "miss text that sits beside or inside images.")


def check_file_size(ctx) -> dict:
    p = ctx["parsed"]
    size_mb = p["file_size_bytes"] / (1024 * 1024)
    if size_mb <= 2:
        return _check("file_size", "File size ≤ 2 MB", "parseability",
                      True, 5, 5, f"{size_mb:.2f} MB.")
    if size_mb <= 5:
        return _check("file_size", "File size", "parseability",
                      True, 3, 5, f"{size_mb:.2f} MB.",
                      "Try to keep under 2 MB — some job portals reject >2 MB.")
    return _check("file_size", "File size", "parseability",
                  False, 0, 5, f"{size_mb:.2f} MB.",
                  "File is too large. Export without embedded images or "
                  "high-res graphics.")


# ---- B. Structure (20) -----------------------------------------------------

def check_sections(ctx) -> dict:
    text = ctx["parsed"]["text"]
    found = {}
    for sec, patterns in _STANDARD_SECTIONS.items():
        found[sec] = any(re.search(p, text, flags=re.IGNORECASE) for p in patterns)
    score = sum(4 for v in found.values() if v)
    missing = [s for s, v in found.items() if not v]
    passed = len(missing) == 0
    detail = (
        "Found sections: " + ", ".join(s for s, v in found.items() if v)
        + ("." if not missing else f". Missing: {', '.join(missing)}.")
    )
    return _check(
        "sections", "Standard sections present", "structure",
        passed, score, 20, detail,
        "Add missing sections with standard English titles (Summary, "
        "Experience, Education, Skills, Projects/Certifications)."
    )


# ---- C. Contact (10) -------------------------------------------------------

_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PHONE_RE = re.compile(r"(\+?\d[\d\-\s()]{7,}\d)")
_LINKEDIN_RE = re.compile(r"linkedin\.com/in/[A-Za-z0-9\-_%]+", re.IGNORECASE)
_GITHUB_RE = re.compile(r"github\.com/[A-Za-z0-9\-_%]+", re.IGNORECASE)


def check_contact(ctx) -> dict:
    text = ctx["parsed"]["text"]
    email = bool(_EMAIL_RE.search(text))
    phone = bool(_PHONE_RE.search(text))
    linkedin = bool(_LINKEDIN_RE.search(text))
    github = bool(_GITHUB_RE.search(text))
    score = (3 if email else 0) + (3 if phone else 0) + (2 if linkedin else 0) + (2 if github else 0)
    passed = score >= 8
    missing = [n for n, ok in [("email", email), ("phone", phone),
                               ("LinkedIn", linkedin), ("GitHub", github)] if not ok]
    detail = "Found: " + ", ".join(n for n, ok in [
        ("email", email), ("phone", phone),
        ("LinkedIn", linkedin), ("GitHub", github)] if ok) or "Nothing."
    return _check(
        "contact", "Contact details complete", "contact",
        passed, score, 10, detail,
        f"Add: {', '.join(missing)} (spell the full URL — some ATS skip "
        "linked text without the URL)."
    )


# ---- D. Dates / formatting (10) -------------------------------------------

_DATE_GOOD_RE = re.compile(
    r"\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s+\d{4}\b",
    re.IGNORECASE,
)
_DATE_NUMERIC_RE = re.compile(r"\b\d{1,2}/\d{2,4}\b")


def check_date_format(ctx) -> dict:
    text = ctx["parsed"]["text"]
    good = len(_DATE_GOOD_RE.findall(text))
    numeric_only = len(_DATE_NUMERIC_RE.findall(text))
    if good >= 2 and numeric_only == 0:
        return _check("dates_fmt", "Dates in MMM YYYY format", "dates_format",
                      True, 5, 5, f"{good} MMM YYYY date(s) detected.")
    if good >= 2:
        return _check("dates_fmt", "Dates mostly standard", "dates_format",
                      True, 3, 5,
                      f"{good} MMM YYYY and {numeric_only} numeric (m/yy) dates.",
                      "Convert numeric dates like 7/23 into Jul 2023.")
    return _check("dates_fmt", "Standard date format", "dates_format",
                  False, 1, 5, f"Only {good} MMM YYYY date(s) found.",
                  "Use 'MMM YYYY – MMM YYYY' (e.g., 'Jul 2023 – Present') for every role.")


def check_present_role(ctx) -> dict:
    text = ctx["parsed"]["text"].lower()
    if "present" in text or "current" in text or "till date" in text:
        return _check("current_role", "Current role marked", "dates_format",
                      True, 5, 5, "Found 'Present' / 'Current' marker.")
    return _check("current_role", "Current role marked", "dates_format",
                  False, 0, 5, "No 'Present' marker in dates.",
                  "Mark your current job's end date as 'Present'. Recruiters "
                  "and ATS use this to flag active candidates.")


# ---- E. Keyword overlap vs JD (20) ----------------------------------------

def check_keywords(ctx) -> dict:
    jd = ctx.get("jd_text") or ""
    text = ctx["parsed"]["text"]
    if not jd.strip():
        return _check("keywords", "JD keyword overlap", "keywords",
                      True, 20, 20,
                      "No JD provided — scored full. Paste a JD or pick a "
                      "preset to grade keyword fit.")
    jd_keywords = extract_keywords(jd, max_keywords=50)
    matched, missing = keyword_overlap(text, jd_keywords)
    total = max(1, len(jd_keywords))
    ratio = len(matched) / total
    score = round(ratio * 20)
    passed = ratio >= 0.60
    detail = (
        f"Matched {len(matched)}/{total} JD keywords ({ratio*100:.0f}%). "
        f"Missing (top 10): {', '.join(missing[:10]) or 'none'}."
    )
    ctx["_matched_keywords"] = matched
    ctx["_missing_keywords"] = missing
    return _check(
        "keywords", "JD keyword overlap ≥ 60%", "keywords",
        passed, score, 20, detail,
        "Add the missing keywords naturally inside Experience bullets AND "
        "the Skills section. Aim for 70-80% overlap."
    )


# ---- F. Metrics / outcomes (10) --------------------------------------------

_BULLET_RE = re.compile(r"(?m)^\s*(?:[\u2022\-\*\u25E6\u2023\u2043\u2219]|\d+\.)\s+(.+)$")
_NUMBER_IN_BULLET_RE = re.compile(r"(\d+%|\d+\s*(hours?|hrs?|days?|minutes?|mins?|seconds?|secs?)|\$\d|\d{2,}|zero|100%)", re.IGNORECASE)


def check_metrics(ctx) -> dict:
    text = ctx["parsed"]["text"]
    bullets = _BULLET_RE.findall(text)
    if len(bullets) < 5:
        return _check("metrics", "Bullets with numbers / outcomes",
                      "metrics", False, 3, 10,
                      f"Only {len(bullets)} bullet(s) detected.",
                      "Use bullet points (•, -, or numbered). Each role "
                      "should have 3-6 bullets.")
    with_numbers = sum(1 for b in bullets if _NUMBER_IN_BULLET_RE.search(b))
    ratio = with_numbers / len(bullets)
    score = round(ratio * 10)
    passed = ratio >= 0.5
    detail = f"{with_numbers}/{len(bullets)} bullets ({ratio*100:.0f}%) contain numbers or outcomes."
    return _check(
        "metrics", "≥50% bullets have numbers", "metrics",
        passed, score, 10, detail,
        "Add measurable outcomes to bullets — %, counts, time saved, SLA, "
        "number of servers/incidents, etc. Recruiter eyes snap to digits."
    )


# ---- G. Acronym expansion (5) ---------------------------------------------

def check_acronyms(ctx) -> dict:
    text = ctx["parsed"]["text"]
    found = detect_acronyms(text)
    if not found:
        return _check("acronyms", "Acronym expansions", "acronyms",
                      True, 5, 5, "No tracked acronyms used.")
    expanded = sum(1 for v in found.values() if v)
    ratio = expanded / len(found)
    score = round(ratio * 5)
    passed = ratio >= 0.6
    missing = [a for a, v in found.items() if not v]
    detail = f"{expanded}/{len(found)} acronyms also show their expansion."
    return _check(
        "acronyms", "Acronyms spelled out at least once", "acronyms",
        passed, score, 5, detail,
        "Spell these out at least once: " + ", ".join(missing[:8])
        + ".  Example: 'AVD (Azure Virtual Desktop)'."
    )


# ---- registry --------------------------------------------------------------

ALL_RULES = [
    # parseability
    check_text_extractable,
    check_page_count,
    check_no_images,
    check_file_size,
    # structure
    check_sections,
    # contact
    check_contact,
    # dates
    check_date_format,
    check_present_role,
    # keywords
    check_keywords,
    # metrics
    check_metrics,
    # acronyms
    check_acronyms,
]


def run_all(ctx: dict[str, Any]) -> list[dict]:
    return [rule(ctx) for rule in ALL_RULES]
