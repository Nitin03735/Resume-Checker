"""Scoring orchestrator — turns parsed resume + optional JD into a scorecard."""

from __future__ import annotations

from typing import Any

from .parser import parse_resume
from .presets import get_preset_jd
from .rules import CATEGORIES, run_all


def _grade(score: int) -> tuple[str, str]:
    if score >= 90:
        return "A+", "Excellent – highly likely to clear ATS and recruiter screens."
    if score >= 80:
        return "A", "Strong – should clear most ATS and recruiter screens."
    if score >= 70:
        return "B", "Good – likely to pass, a few tweaks will boost ranking."
    if score >= 60:
        return "C", "Borderline – fix the flagged issues before applying."
    if score >= 40:
        return "D", "Weak – ATS will likely rank you below the fold."
    return "F", "Will not pass ATS reliably – significant rework needed."


def analyze_resume(
    file_path: str,
    jd_text: str | None = None,
    preset_id: str | None = None,
) -> dict[str, Any]:
    """Parse + score + return a UI-friendly payload."""
    parsed = parse_resume(file_path)

    # Resolve JD text (preset wins only if jd_text not provided)
    if not jd_text and preset_id:
        jd_text = get_preset_jd(preset_id)

    ctx = {"parsed": parsed, "jd_text": jd_text or ""}
    checks = run_all(ctx)

    # Aggregate by category
    cat_totals: dict[str, dict[str, Any]] = {
        c: {"score": 0, "max": max_, "checks": []} for c, max_ in CATEGORIES.items()
    }
    for ch in checks:
        bucket = cat_totals.setdefault(
            ch["category"], {"score": 0, "max": 0, "checks": []}
        )
        bucket["score"] += ch["score"]
        bucket["checks"].append(ch)

    overall = sum(b["score"] for b in cat_totals.values())
    grade, verdict = _grade(overall)

    suggestions = [c["suggestion"] for c in checks if c["suggestion"]]

    return {
        "overall_score": overall,
        "max_score": sum(CATEGORIES.values()),
        "grade": grade,
        "verdict": verdict,
        "categories": cat_totals,
        "suggestions": suggestions,
        "parsed_summary": {
            "format": parsed["format"],
            "pages": parsed["pages"],
            "words": parsed["word_count"],
            "chars": parsed["char_count"],
            "images": parsed["image_count"],
            "tables": parsed["has_tables"],
            "fonts": parsed["fonts_used"][:10],
            "file_size_mb": round(parsed["file_size_bytes"] / (1024 * 1024), 2),
            "errors": parsed["errors"],
        },
        "jd_used": bool(jd_text and jd_text.strip()),
        "matched_keywords": ctx.get("_matched_keywords", []),
        "missing_keywords": ctx.get("_missing_keywords", []),
    }
