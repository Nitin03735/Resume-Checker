"""Render a TailoredResume dict to a Word .docx file (BytesIO)."""

from __future__ import annotations

import io
from typing import Any

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ACCENT = RGBColor(0x07, 0x3B, 0x9C)
INK = RGBColor(0x15, 0x20, 0x2B)
MUTED = RGBColor(0x4B, 0x5A, 0x6B)


def _hr_under(paragraph) -> None:
    p = paragraph._p
    pPr = p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "073B9C")
    pBdr.append(bottom)
    pPr.append(pBdr)


def _h2(doc, text: str):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text.upper())
    r.bold = True
    r.font.size = Pt(11)
    r.font.name = "Calibri"
    r.font.color.rgb = ACCENT
    _hr_under(p)


def _p(doc, text: str, *, bold=False, size=10.5, color=INK, space_after=4):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(space_after)
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(size)
    r.font.color.rgb = color
    return p


def _bullet(doc, text: str, size=10.5):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.left_indent = Cm(0.6)
    r = p.add_run(text)
    r.font.size = Pt(size)
    r.font.color.rgb = INK


def render_docx(tailored: dict[str, Any]) -> io.BytesIO:
    doc = Document()
    for section in doc.sections:
        section.top_margin = Cm(1.4)
        section.bottom_margin = Cm(1.4)
        section.left_margin = Cm(1.6)
        section.right_margin = Cm(1.6)

    base = doc.styles["Normal"]
    base.font.name = "Calibri"
    base.font.size = Pt(10.5)

    # ---- header ----
    name = tailored.get("name") or "[Your Name]"
    title = tailored.get("title") or ""
    _p(doc, name, bold=True, size=22, space_after=0)
    if title:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        r = p.add_run(title)
        r.bold = True
        r.font.size = Pt(11.5)
        r.font.color.rgb = ACCENT

    contact = tailored.get("contact") or {}
    bits = [contact.get("location"), contact.get("phone"),
            contact.get("email"), contact.get("linkedin"),
            contact.get("github")]
    bits = [b for b in bits if b]
    if bits:
        p = _p(doc, "   |   ".join(bits), size=10, color=MUTED, space_after=2)
        _hr_under(p)

    # ---- summary ----
    if tailored.get("summary"):
        _h2(doc, "Professional Summary")
        _p(doc, tailored["summary"])

    # ---- skills ----
    skills = tailored.get("skills") or []
    if skills:
        _h2(doc, "Skills")
        _p(doc, " · ".join(skills))

    # ---- experience ----
    exp = tailored.get("experience") or []
    if exp:
        _h2(doc, "Professional Experience")
        for role in exp:
            r_role = role.get("role", "")
            org = role.get("org", "")
            loc = role.get("location", "")
            dates = role.get("dates", "")
            header = r_role
            right = dates
            meta_left = "  —  ".join(x for x in [org, loc] if x)

            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(0)
            rr = p.add_run(header)
            rr.bold = True
            rr.font.size = Pt(12)
            rr.font.color.rgb = INK

            if meta_left or right:
                p2 = doc.add_paragraph()
                p2.paragraph_format.space_after = Pt(2)
                p2.add_run(meta_left).font.size = Pt(10.5)
                p2.paragraph_format.tab_stops.add_tab_stop(
                    Cm(16.5), WD_ALIGN_PARAGRAPH.RIGHT
                )
                p2.add_run("\t")
                rr = p2.add_run(right)
                rr.italic = True
                rr.font.size = Pt(10.5)
                rr.font.color.rgb = MUTED

            for b in role.get("bullets") or []:
                _bullet(doc, b)

    # ---- projects ----
    projects = tailored.get("projects") or []
    if projects:
        _h2(doc, "Highlighted Projects")
        for pr in projects:
            name = pr.get("name") or pr.get("role") or ""
            stack = pr.get("stack") or ""
            if name:
                _p(doc, name, bold=True, size=11, space_after=0)
            if stack:
                p = doc.add_paragraph()
                p.paragraph_format.space_after = Pt(2)
                rr = p.add_run(stack)
                rr.italic = True
                rr.font.size = Pt(9.5)
                rr.font.color.rgb = MUTED
            for b in pr.get("bullets") or []:
                _bullet(doc, b)

    # ---- education ----
    edu = tailored.get("education") or []
    if edu:
        _h2(doc, "Education")
        for e in edu:
            if isinstance(e, str):
                _p(doc, e)
            else:
                parts = [e.get("degree", ""), e.get("institution", ""), e.get("dates", "")]
                _p(doc, "   —   ".join(x for x in parts if x))

    # ---- certifications ----
    certs = tailored.get("certifications") or []
    if certs:
        _h2(doc, "Certifications")
        for c in certs:
            _bullet(doc, c)

    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf
