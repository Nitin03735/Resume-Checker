(() => {
  const $ = (sel) => document.querySelector(sel);

  // Elements
  const form = $("#form");
  const fileInput = $("#file");
  const dropzone = $("#dropzone");
  const filenameEl = $("#filename");
  const presetSel = $("#preset");
  const jdInput = $("#jd");
  const submitBtn = $("#submit");
  const tailorBtn = $("#tailorBtn");
  const resetBtn = $("#reset");
  const results = $("#results");
  const tailorPane = $("#tailor");
  const dlDocxBtn = $("#dlDocx");
  const dlPdfBtn = $("#dlPdf");

  let lastTailored = null; // most recent tailored JSON

  // --- load presets -----------------------------------------------------
  fetch("/api/presets")
    .then((r) => r.json())
    .then((data) => {
      for (const p of data.presets || []) {
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = p.label;
        presetSel.appendChild(opt);
      }
    })
    .catch(() => {});

  // --- drag & drop ------------------------------------------------------
  ["dragenter", "dragover"].forEach((ev) =>
    dropzone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropzone.classList.add("drag");
    })
  );
  ["dragleave", "drop"].forEach((ev) =>
    dropzone.addEventListener(ev, (e) => {
      e.preventDefault();
      dropzone.classList.remove("drag");
    })
  );
  dropzone.addEventListener("drop", (e) => {
    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      updateFilename();
    }
  });
  fileInput.addEventListener("change", updateFilename);

  function updateFilename() {
    const f = fileInput.files[0];
    if (f) {
      filenameEl.classList.remove("hidden");
      filenameEl.textContent = `✓ ${f.name} (${(f.size / 1024).toFixed(1)} KB)`;
    } else {
      filenameEl.classList.add("hidden");
    }
  }

  resetBtn.addEventListener("click", () => {
    results.classList.add("hidden");
    tailorPane.classList.add("hidden");
    filenameEl.classList.add("hidden");
    jdInput.value = "";
    presetSel.value = "";
    lastTailored = null;
  });

  // --- analyze ----------------------------------------------------------
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const file = fileInput.files[0];
    if (!file) return alert("Pick a resume file first.");
    submitBtn.disabled = true;
    submitBtn.textContent = "Analyzing…";

    const fd = buildForm(file);
    try {
      const res = await fetch("/api/analyze", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) return alert(data.error || "Analysis failed.");
      render(data);
    } catch (err) {
      alert("Request failed: " + err.message);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Analyze";
    }
  });

  // --- tailor -----------------------------------------------------------
  tailorBtn.addEventListener("click", async () => {
    const file = fileInput.files[0];
    if (!file) return alert("Pick a resume file first.");
    const jd = jdInput.value.trim();
    const preset = presetSel.value;
    if (!jd && !preset) {
      return alert("Paste a Job Description or pick a preset first.");
    }
    tailorBtn.disabled = true;
    tailorBtn.textContent = "Tailoring…";

    const fd = buildForm(file);
    try {
      const res = await fetch("/api/tailor", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) return alert(data.error || "Tailoring failed.");
      lastTailored = data;
      renderTailor(data);
    } catch (err) {
      alert("Request failed: " + err.message);
    } finally {
      tailorBtn.disabled = false;
      tailorBtn.textContent = "✨ Tailor to JD";
    }
  });

  // --- download ---------------------------------------------------------
  dlDocxBtn.addEventListener("click", () => downloadTailored("docx"));
  dlPdfBtn.addEventListener("click", () => downloadTailored("pdf"));

  async function downloadTailored(fmt) {
    if (!lastTailored) return alert("Tailor the resume first.");
    const btn = fmt === "docx" ? dlDocxBtn : dlPdfBtn;
    btn.disabled = true;
    const originalText = btn.textContent;
    btn.textContent = "Preparing…";
    try {
      const res = await fetch(`/api/download/${fmt}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(lastTailored),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        return alert(err.error || `Download failed (${res.status}).`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const nameRoot = (lastTailored.name || "resume").replace(/[^A-Za-z0-9._-]+/g, "_");
      a.href = url;
      a.download = `${nameRoot}_Tailored.${fmt}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert("Download failed: " + err.message);
    } finally {
      btn.disabled = false;
      btn.textContent = originalText;
    }
  }

  // --- helpers ----------------------------------------------------------
  function buildForm(file) {
    const fd = new FormData();
    fd.append("file", file);
    const jd = jdInput.value.trim();
    const preset = presetSel.value;
    if (jd) fd.append("jd_text", jd);
    if (preset) fd.append("preset_id", preset);
    return fd;
  }

  function tone(score, max) {
    const pct = score / max;
    if (pct >= 0.8) return "good";
    if (pct >= 0.6) return "mid";
    return "bad";
  }

  function render(d) {
    results.classList.remove("hidden");
    results.scrollIntoView({ behavior: "smooth", block: "start" });

    const ring = $("#ringFg");
    const toneCls = tone(d.overall_score, d.max_score);
    ring.classList.remove("good", "mid", "bad");
    ring.classList.add(toneCls);
    const dash = 326.7;
    const offset = dash * (1 - d.overall_score / d.max_score);
    requestAnimationFrame(() => (ring.style.strokeDashoffset = offset.toFixed(1)));
    animateNumber("#scoreNum", 0, d.overall_score, 900);

    const grade = $("#grade");
    grade.textContent = d.grade;
    grade.classList.remove("good", "mid", "bad");
    grade.classList.add(toneCls);

    $("#verdictText").textContent = d.verdict;
    const ps = d.parsed_summary;
    $("#metaLine").textContent =
      `${d.filename || ""} · ${ps.format?.toUpperCase() || ""} · ${ps.pages} page(s) · ${ps.words} words · ${ps.file_size_mb} MB`;

    const cats = $("#categories");
    cats.innerHTML = "";
    for (const [name, info] of Object.entries(d.categories)) {
      const row = document.createElement("div");
      row.className = "cat";
      row.innerHTML = `
        <div class="name">${name.replace("_", " ")}</div>
        <div class="bar"><span style="width:0"></span></div>
        <div class="val">${info.score}/${info.max}</div>`;
      cats.appendChild(row);
      requestAnimationFrame(() => {
        const bar = row.querySelector(".bar > span");
        bar.style.width = `${(info.score / info.max) * 100}%`;
        const t = tone(info.score, info.max);
        bar.style.background =
          t === "good" ? "var(--ok)" : t === "mid" ? "var(--warn)" : "var(--bad)";
      });
    }

    const checks = $("#checks");
    checks.innerHTML = "";
    for (const info of Object.values(d.categories)) {
      for (const c of info.checks) {
        const t = tone(c.score, c.max);
        const mark = t === "good" ? "✓" : t === "mid" ? "!" : "✕";
        const el = document.createElement("div");
        el.className = `check ${t === "good" ? "ok" : t === "mid" ? "warn" : "bad"}`;
        el.innerHTML = `
          <div class="mark">${mark}</div>
          <div>
            <div class="label">${escape(c.label)} <span style="color:var(--muted);font-weight:normal">(${c.score}/${c.max})</span></div>
            <div class="detail">${escape(c.detail || "")}</div>
            ${c.suggestion ? `<div class="fix">→ ${escape(c.suggestion)}</div>` : ""}
          </div>`;
        checks.appendChild(el);
      }
    }

    const matched = $("#matched");
    const missing = $("#missing");
    matched.innerHTML = "";
    missing.innerHTML = "";
    if (!d.jd_used) {
      matched.innerHTML = '<div class="chip">No JD provided</div>';
      missing.innerHTML = '<div class="chip">—</div>';
    } else {
      (d.matched_keywords || []).slice(0, 60).forEach((k) => matched.appendChild(makeChip(k)));
      (d.missing_keywords || []).slice(0, 60).forEach((k) => missing.appendChild(makeChip(k)));
      if (!matched.childElementCount) matched.innerHTML = '<div class="chip">None matched</div>';
      if (!missing.childElementCount) missing.innerHTML = '<div class="chip">None missing — great overlap</div>';
    }

    const sug = $("#suggestions");
    sug.innerHTML = "";
    if (!d.suggestions.length) {
      sug.innerHTML = "<li>No major issues found. Nice work.</li>";
    } else {
      for (const s of d.suggestions) {
        const li = document.createElement("li");
        li.textContent = s;
        sug.appendChild(li);
      }
    }
  }

  function renderTailor(t) {
    tailorPane.classList.remove("hidden");
    tailorPane.scrollIntoView({ behavior: "smooth", block: "start" });

    const meta = t._meta || {};
    $("#tailorMeta").textContent =
      `Provider: ${meta.provider || "rule_based"}` +
      (meta.added_skills_count != null ? ` · +${meta.added_skills_count} skills added` : "") +
      (meta.weak_bullets != null ? ` · ${meta.weak_bullets} weak bullet(s)` : "");

    const changes = $("#changes");
    changes.innerHTML = "";
    (t.changes || []).forEach((c) => {
      const li = document.createElement("li");
      li.textContent = c;
      changes.appendChild(li);
    });
    if (!changes.children.length) changes.innerHTML = "<li>No changes recorded.</li>";

    // Header
    $("#pvName").textContent = t.name || "[Your Name]";
    $("#pvTitle").textContent = t.title || "";
    const c = t.contact || {};
    const bits = [c.location, c.phone, c.email, c.linkedin, c.github].filter(Boolean);
    $("#pvContact").textContent = bits.join("   |   ") || "—";

    $("#pvSummary").textContent = t.summary || "—";

    const sk = $("#pvSkills");
    sk.innerHTML = "";
    (t.skills || []).forEach((s) => sk.appendChild(makeChip(s)));
    if (!sk.children.length) sk.innerHTML = '<div class="chip">—</div>';

    const exp = $("#pvExperience");
    exp.innerHTML = "";
    (t.experience || []).forEach((r) => {
      const div = document.createElement("div");
      div.className = "prev-role";
      div.innerHTML = `
        <div class="r-head">
          <div class="r-title">${escape(r.role || "")}</div>
          <div class="r-dates">${escape(r.dates || "")}</div>
        </div>
        <div class="r-org">${escape([r.org, r.location].filter(Boolean).join("  —  "))}</div>
        <ul>${(r.bullets || []).map((b) => `<li>${escape(b)}</li>`).join("")}</ul>`;
      exp.appendChild(div);
    });
    if (!exp.children.length) exp.innerHTML = "<p>—</p>";

    const projWrap = $("#pvProjectsWrap");
    const projs = t.projects || [];
    if (projs.length) {
      projWrap.classList.remove("hidden");
      const pel = $("#pvProjects");
      pel.innerHTML = "";
      projs.forEach((p) => {
        const div = document.createElement("div");
        div.className = "prev-role";
        div.innerHTML = `
          <div class="r-title">${escape(p.name || p.role || "")}</div>
          <div class="r-org">${escape(p.stack || "")}</div>
          <ul>${(p.bullets || []).map((b) => `<li>${escape(b)}</li>`).join("")}</ul>`;
        pel.appendChild(div);
      });
    } else {
      projWrap.classList.add("hidden");
    }

    const eduWrap = $("#pvEduWrap");
    const edu = t.education || [];
    if (edu.length) {
      eduWrap.classList.remove("hidden");
      const el = $("#pvEducation");
      el.innerHTML = "";
      edu.forEach((e) => {
        const p = document.createElement("p");
        if (typeof e === "string") p.textContent = e;
        else p.textContent = [e.degree, e.institution, e.dates].filter(Boolean).join("  —  ");
        el.appendChild(p);
      });
    } else {
      eduWrap.classList.add("hidden");
    }

    const certsWrap = $("#pvCertsWrap");
    const certs = t.certifications || [];
    const cel = $("#pvCerts");
    cel.innerHTML = "";
    if (certs.length) {
      certsWrap.classList.remove("hidden");
      certs.forEach((cert) => {
        const li = document.createElement("li");
        li.textContent = cert;
        cel.appendChild(li);
      });
    } else {
      certsWrap.classList.add("hidden");
    }
  }

  function makeChip(text) {
    const c = document.createElement("div");
    c.className = "chip";
    c.textContent = text;
    return c;
  }

  function animateNumber(sel, from, to, ms) {
    const el = $(sel);
    const start = performance.now();
    const step = (t) => {
      const p = Math.min(1, (t - start) / ms);
      const v = Math.round(from + (to - from) * p);
      el.textContent = v;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }

  function escape(s) {
    return String(s).replace(/[&<>"']/g, (c) => (
      { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
    ));
  }
})();
